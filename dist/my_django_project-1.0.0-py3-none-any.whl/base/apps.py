
# apps.py

from django.apps import AppConfig

